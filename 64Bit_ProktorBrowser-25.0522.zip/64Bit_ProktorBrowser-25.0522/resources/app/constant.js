module.exports = {
    mainwindow: {
      width: {
        linux: 500,
        win32: 500,
        darwin: 500
      },
      height: {
        linux: 275,
        win32: 275,
        darwin: 300
      }
    },
    aboutwindow: {
      width: {
        linux: 500,
        win32: 500,
        darwin: 500
      },
      height: {
        linux: 250,
        win32: 250,
        darwin: 250
      }
    },
    passwordwindow: {
      width: {
        linux: 300,
        win32: 300,
        darwin: 300
      },
      height: {
        linux: 200,
        win32: 200,
        darwin: 225
      }
    },
    settingsadminwindow: {
      width: {
        linux: 500,
        win32: 500,
        darwin: 500
      },
      height: {
        linux: 425,
        win32: 375,
        darwin: 425
      }
    }
  }
  